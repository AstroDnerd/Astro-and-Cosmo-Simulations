# Contains the constants to be shared throughout all unittests.
# Typical value for precision is 30

precision = 30
